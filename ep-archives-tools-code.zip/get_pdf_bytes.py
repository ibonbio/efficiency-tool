from io import BytesIO
from typing import BinaryIO

import logging
from io import BytesIO
from botocore.exceptions import BotoCoreError, ClientError
from boto3.resources.base import ServiceResource
from typing import Union

# Configure module-level logger
logger = logging.getLogger(__name__)

def get_pdf_bytes(s3: Union[ServiceResource, 'boto3.client'], bucket: str, obj_key: str) -> BytesIO:
    """
    Retrieves a PDF file from an S3 bucket and returns it as a BytesIO object.

    Parameters:
        s3 (boto3 client or resource): A boto3 S3 client or resource.
        bucket (str): Name of the S3 bucket.
        obj_key (str): Key (path/filename) of the object in the S3 bucket.

    Returns:
        BytesIO: In-memory binary stream of the PDF content.

    Raises:
        Exception: If the S3 object cannot be retrieved or read.
    """
    try:
        logger.info(f"Attempting to fetch '{obj_key}' from bucket '{bucket}'")
        response = s3.get_object(Bucket=bucket, Key=obj_key)
        pdf_data = response["Body"].read()
        logger.info(f"Successfully fetched '{obj_key}' ({len(pdf_data)} bytes)")
        return BytesIO(pdf_data)

    except ClientError as e:
        logger.error(f"AWS ClientError while fetching '{obj_key}' from '{bucket}': {e}")
        raise

    except BotoCoreError as e:
        logger.error(f"BotoCoreError while fetching '{obj_key}' from '{bucket}': {e}")
        raise

    except Exception as e:
        logger.exception(f"Unexpected error occurred while reading PDF from S3: {e}")
        raise
