# Copyright 2025 European Parliament.
#
# Licensed under the European Union Public License (EUPL), Version 1.2 or subsequent
# versions of the EUPL (the "Licence"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
# https://eupl.eu/1.2/en/
#
# or in the "license" file accomying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.

import logging
import json
from presigned_url_generator import generate_presigned_put_url, generate_presigned_delete_url, \
      generate_presigned_list_bucket_url, generate_presigned_get_url

# Configure logging
logger = logging.getLogger(__name__)


def lambda_handler(event, context):
    """
    Lambda function to generate a presigned S3 PUT URL.

    Expects:
        - queryStringParameters.file_name (required)
        - queryStringParameters.content_type (optional)

    Returns:
        - HTTP 200 with presigned URL in the body if successful
        - HTTP 400 with an error message if input is missing/invalid
    """

    try:
        # Extract query parameters
        params = event.get("queryStringParameters") or {}
        file_name = params.get("file_name", None)
        content_type = params.get("content_type")
        client_method = params.get("client_method", "put_object")
        prefix = params.get("prefix", None)
        bucket_name = params.get("bucket_name", None)
        if bucket_name is None:
            logger.error("Missing required environment variable: ep_bucket_name")
            raise EnvironmentError("Bucket name is not set as environment variable 'ep_bucket_name'.")

        # Generate presigned URL
        if client_method == "put_object":
            presigned_url = generate_presigned_put_url(bucket_name, file_name=file_name, content_type=content_type)
            logger.info("Presigned URL for put_object method successfully generated.")
        elif client_method == "get_object":
            presigned_url = generate_presigned_get_url(bucket_name, file_name)
            logger.info("Presigned URL for get_object method successfully generated.")
        elif client_method == "delete_object":
            presigned_url = generate_presigned_delete_url(bucket_name, file_name)
            logger.info("Presigned URL for delete_object method successfully generated.")
        elif client_method == "list_bucket":
            presigned_url = generate_presigned_list_bucket_url(bucket_name, prefix)
            logger.info("Presigned URL for list_bucket method successfully generated.")
        else:
            logger.error("Wrong client method.")
            return {
                "statusCode": 400,
                "body": "Wrong client method."
            }

        return {
            "statusCode": 200,
            "body": json.dumps({"url": presigned_url})
        }

    except Exception as e:
        # Unexpected error
        logger.exception("Unexpected error occurred.")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }


# Entry point for the script when run locally
if __name__ == "__main__":

    event = {"queryStringParameters": {"client_method": "list_bucket",
                                       "bucket_name": "ep-archives-tools-code",
                                       "prefix": "tmp/frontend/file_mgmt_pages/"}
            }
    # event = {"queryStringParameters": {"client_method": "delete_object",
    #          "file_name": "Pippo.txt",
    #          "bucket_name": "ep-archives-tools-docs"}}
    # event = {
    #         "queryStringParameters": {
    #         "file_name": "Away day DISC 21092023.pdf",
    #         "client_method": "get_object",
    #         "bucket_name": "ep-archives-tools-docs"
    #       }
    #     }
    response = lambda_handler(event, None)

    print(response)