# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
#
# Permission is hereby granted, free of charge, to any person obtaining a copy of this
# software and associated documentation files (the "Software"), to deal in the Software
# without restriction, including without limitation the rights to use, copy, modify,
# merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
# PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""Lambda to handle interactions with Bedrock foundation models"""

import logging
import json
import os
from io import BytesIO
import boto3

from markitdown import MarkItDown, DocumentConverterResult

from get_pdf_bytes import get_pdf_bytes

logger = logging.getLogger()
logger.setLevel(os.getenv("log_level", "INFO"))

def lambda_handler(event, context):
    """
    Event will provide:
    * obj_keys of the file to convert ({"obj_keys": List[str]})

    Lambda returns json object {"md_contents": List{{"obj_key": obj_key, "md_content": md_content}])
    """
    # When this lambda is called by the frontend via API gateway, the event
    # has a 'body' key. When this lambda is called by other lambdas, this is
    # unnecessary

    logger.debug(f"{event=}")

    if "body" in event:
        event = json.loads(event["body"])

    obj_keys = event["obj_keys"]
    bucket = event["bucket"]
    md_contents = {"md_contents": []}

    try:
        s3 = boto3.client("s3")
        md = MarkItDown()
        for obj_key in obj_keys:
            content = get_pdf_bytes(s3, bucket, obj_key)
            md_content: DocumentConverterResult = md.convert(content)
            md_contents["md_contents"].append({"obj_key": obj_key, "md_content": md_content.text_content})

    except Exception as e:
        return {"statusCode": 500, "body": f"Internal server error: {e}"}

    return {"statusCode": 200, "body": json.dumps(md_contents)}

# Entry point for the script when run locally
if __name__ == "__main__":

    event = {"bucket": "ep-archives-tools-docs", "obj_keys": ["Décisions Bureau 12 06 2006.pdf"]}

    response = lambda_handler(event, None)
    body = json.loads(response["body"])
    print(body["md_contents"][0])