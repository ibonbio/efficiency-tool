import json
import logging
from typing import Any, Dict

from ep_archives_common_tools.prompt_manager import PromptTemplatesManager

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    AWS Lambda function to retrieve a prompt template based on LLM model ID and template name.
    Handles both API Gateway (with 'body') and direct invocations (raw event dicts).

    Args:
        event (dict): The input event, possibly including a 'body' key with a JSON string.
        context: Lambda context (unused).

    Returns:
        dict: API Gateway-compatible response with statusCode and body.
    """
    try:
        # Normalize the request payload
        if "body" in event:
            try:
                request_params = json.loads(event["body"])
            except json.JSONDecodeError:
                logger.warning("Invalid JSON in 'body'")
                return _response(400, {"error": "Invalid JSON in request body"})
        else:
            request_params = event

        llm_model_id = request_params.get("llm_model_id")
        template_name = request_params.get("template_name")

        if not llm_model_id or not template_name:
            logger.warning(f"Missing parameters: llm_model_id={llm_model_id}, template_name={template_name}")
            return _response(400, {"error": "Missing 'llm_model_id' or 'template_name'"})

        logger.info(f"Searching prompt: model_id='{llm_model_id}', template='{template_name}'")
        template_manager = PromptTemplatesManager()
        prompt_template = template_manager.get_prompt_template(llm_model_id, template_name)

        if prompt_template is None:
            logger.info("Prompt template not found.")
            return _response(404, {"error": "Prompt template not found."})

        return _response(200, prompt_template)

    except Exception as e:
        logger.exception("Unhandled error during prompt template retrieval.")
        return _response(500, {"error": "Internal server error"})


def _response(status_code: int, body: Any) -> Dict[str, Any]:
    """
    Helper function to format API Gateway responses.

    Args:
        status_code (int): HTTP status code.
        body (Any): Response body to be JSON-encoded.

    Returns:
        dict: Formatted API response.
    """
    return {
        "statusCode": status_code,
        "headers": {"Content-Type": "application/json; charset=utf-8"},
        "body": json.dumps(body, ensure_ascii=False)
    }
