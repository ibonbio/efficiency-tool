# Copyright 2025 European Parliament.
#
# Licensed under the European Union Public License (EUPL), Version 1.2 or subsequent
# versions of the EUPL (the "Licence"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
# https://eupl.eu/1.2/en/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.
import json
import os
import logging
import time
from typing import List

from heavy_job_pipeline.pipeline_tables_manager import EtPipelineManager
from heavy_job_pipeline.sqs_manager import EtSqsManager

logger = logging.getLogger()
logger.setLevel(logging.INFO)


QUEUE_NAME = os.environ["OCR_QUEUE_NAME"]
AWS_REGION = os.environ.get("AWS_REGION", "eu-central-1")

pipeline = EtPipelineManager()
pipeline.initialize()
sqs_manager = EtSqsManager(queue_name=QUEUE_NAME, region_name=AWS_REGION)

def build_md_key(pdf_key: str, output_prefix: str) -> str:
    """
    Convert:
      in_prefix/doc1.xyz → out-prefix/doc1.md

      If no extension is present, the .md extension is added to the file name.
    """

    file_name = pdf_key.rsplit("/", 1)[-1]
    file_name_elements = file_name.rsplit(".", 1)

    return f"{output_prefix.rstrip('/')}/{file_name_elements[0]}.md"


def lambda_handler(event, context):

    user_id: str = event["user_id"]
    doc_objects: List[str] = event["pdf_objects"]
    input_prefix: str = event["ocr_input_prefix"]
    output_prefix: str = event["ocr_output_prefix"]

    # --- Create batch ---
    upload_keys = [f"{input_prefix}/{doc_object}" for doc_object in doc_objects]

    batch_id = pipeline.create_batch(
        user_id=user_id,
        total_files=len(upload_keys),
        job_type="OCR"
    )

    if not batch_id:
        raise RuntimeError("Failed to create batch")

    # --- Build SQS messages ---
    messages = []

    for upload_key in upload_keys:
        md_key = build_md_key(upload_key, output_prefix)

        job_id = pipeline.create_job(
            batch_id=batch_id,
            pdf_obj_key=upload_key,
            md_obj_key=md_key,
            job_type="OCR"
        )

        if not job_id:
            logger.warning("Skipping job for %s", upload_key)
            continue

    body = {
        "batch_id": batch_id,
        "user_name": user_id,
        "bucket": "ep-archives-tools-docs"
    }

    messages.append({
        "body": json.dumps(body),
        "attributes": {
            "job_type": {
                "StringValue": "OCR",
                "DataType": "String"
            }
        }
    })

    response = sqs_manager.send_messages(messages)

    print(response)

    logger.info(
        f"Submitted OCR process, batch_id={batch_id} - Response = {response}")

    return {
        "statusCode": 200,
        "batch_id": batch_id,
        "submitted_jobs": len(messages)
    }


def main():
    import boto3

    # Get S3 parameters from event
    event = {
        "user_id": "demo",
        "s3_bucket": "ep-archives-tools-docs",  # S3 bucket name
        "ocr_input_prefix": "docs",  # S3 folder prefix
        "ocr_output_prefix": "docs"
    }

    # Initialize S3 client
    s3_client = boto3.client('s3', region_name=AWS_REGION)

    bucket_name = event["s3_bucket"]
    s3_prefix = event["ocr_input_prefix"]
    user_id = event["user_id"]

    try:
        # List objects in the S3 folder
        paginator = s3_client.get_paginator('list_objects_v2')
        pages = paginator.paginate(Bucket=bucket_name, Prefix=f"users/{user_id}/{s3_prefix}")

        for page in pages:
            if 'Contents' not in page:
                print(f"No files found in s3://{bucket_name}/users/{user_id}/{s3_prefix}")
                continue

            for obj in page['Contents']:
                s3_key = obj['Key']

                # Skip if it's a folder (ends with /)
                if s3_key.endswith('/'):
                    continue

                if "attach" not in s3_key:
                    # Extract filename from the full S3 key
                    file_name = s3_key.split('/')[-1]

                    # Prepare event for lambda_handler
                    lambda_event = {
                        "user_id": event["user_id"],
                        "ocr_input_prefix": event["ocr_input_prefix"],
                        "pdf_objects": [file_name],
                        "ocr_output_prefix": event["ocr_output_prefix"]
                    }

                    print(f"Processing: {s3_key}")
                    print(lambda_event)

                    result = lambda_handler(lambda_event, None)
                    print(json.dumps(result))
                    time.sleep(5)

                else:
                    print(f"Outlook attachment document {s3_key} not processed.")


    except Exception as e:
        logger.error(f"Error listing S3 objects: {str(e)}")
        raise

if __name__ == '__main__':
    main()
