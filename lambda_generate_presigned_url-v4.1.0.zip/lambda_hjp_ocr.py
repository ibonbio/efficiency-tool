# Copyright 2025 European Parliament.
#
# Licensed under the European Union Public License (EUPL), Version 1.2 or subsequent
# versions of the EUPL (the "Licence"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
# https://eupl.eu/1.2/en/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.
import logging
import json
import os
from typing import List, Dict

from ep_archives_common_tools.config_manager import get_configuration
from ep_archives_common_tools.s3_client import EPArchivesToolsS3Client

from heavy_job_pipeline.ocr_worker import EtOcrWorker
from heavy_job_pipeline.processor import EtHeavyJobProcessor
from heavy_job_pipeline.pipeline_tables_manager import EtPipelineManager

# Configure root logger.
# The log level can be controlled via the Lambda environment variable `log_level`
# (e.g. DEBUG, INFO, WARNING).
logger = logging.getLogger()
logger.setLevel(os.getenv("log_level", "INFO"))

cached_config = get_configuration()

def lambda_handler(event, context):
    """
    AWS Lambda entry point triggered by an SQS event source mapping.

    This function processes OCR jobs delivered via SQS messages.
    It supports:
    - batch processing (multiple messages per invocation)
    - partial batch failure reporting
    - hash-based idempotency to avoid duplicate OCR processing

    Expected event format:
    {
        "Records": [
            {
                "messageId": "...",
                "body": "{...JSON...}"
            }
        ]
    }

    Return value:
    {
        "batchItemFailures": [
            {"itemIdentifier": "<messageId>"}
        ]
    }

    Only messages listed in `batchItemFailures` will be retried by SQS.
    """

    # Extract SQS records from the event.
    # If no records are present, return an empty failure list so the
    # invocation is considered successful.

    records = event.get("Records", [])
    if not records:
        return {"batchItemFailures": []}

    pipeline_mgr = EtPipelineManager()
    pipeline_mgr.initialize()

    # Create the OCR worker and the heavy job processor.
    # These objects are reused for all messages in the batch.
    ocr_worker = EtOcrWorker()
    ocr_worker.s3_client = EPArchivesToolsS3Client(
            cached_config.get("aws", {}).get("s3_docs_bucket_name", "ep-archives-tools-docs"),
            cached_config.get("config", {}).get("presigned_url_api", "Not defined.")
        )

    processor = EtHeavyJobProcessor(pipeline_mgr, ocr_worker)

    # List of message identifiers that failed processing.
    # Required for SQS partial batch failure support.
    batch_item_failures: List[Dict[str, str]] = []

    for record in records:
        # SQS message identifier (used for partial failure reporting)
        message_id = record.get("messageId")

        try:
            body = json.loads(record["body"])

            # Extract mandatory business fields.
            batch_id = body.get("batch_id")
            user_name = body.get("user_name")

            # Validate required fields early.
            # Invalid messages are treated as failures and retried / sent to DLQ.
            if not batch_id or not user_name:
                raise ValueError("Missing required fields")

            # Attempt to acquire the idempotency lock in DynamoDB.
            # This uses a conditional write to ensure only one Lambda
            # invocation processes this job.
            idem_key = pipeline_mgr.compute_idempotency_key(body)

            if not pipeline_mgr.acquire_idempotency_lock(idem_key, batch_id):
                logger.info(
                    "Duplicate job skipped message_id=%s idempotency_key=%s",
                    message_id,
                    idem_key,
                )
                continue  # ACK message

            # -------- OCR processing --------
            # -------- Processing --------
            # Execute the OCR pipeline for this job.
            # Any exception raised here will cause the message to be retried.
            processor.run(body)

            # Mark the idempotency record as DONE.
            # From now on, duplicate messages with the same key
            # will be ignored.
            pipeline_mgr.mark_idempotency_done(idem_key)

            logger.info(
                "Processed message_id=%s batch_id=%s",
                message_id,
                batch_id,
            )

        except Exception:
            # Any exception means this specific message failed.
            # We log the full stack trace and mark only this message
            # as failed so that it will be retried by SQS.
            logger.exception(
                "Failed message_id=%s – will retry",
                message_id,
            )
            batch_item_failures.append(
                {"itemIdentifier": message_id}
            )

    # Return the list of failed message identifiers.
    # Messages NOT listed here are automatically deleted from the queue.
    return {"batchItemFailures": batch_item_failures}


if __name__ == "__main__":
    # Local test harness to allow running the Lambda handler
    # outside of AWS for development and debugging.
    event = {
        "Records": [
            {
                "body": json.dumps({
                    "bucket": "ep-archives-tools-docs",
                    "user_name": "demo",
                    "batch_id": "3a2c762d-3b2c-4e7e-b469-dcb5ed9b08ed"
                })
            }
        ]
    }

    response = lambda_handler(event, None)
    print(json.dumps(response))
