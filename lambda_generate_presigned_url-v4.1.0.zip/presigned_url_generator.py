# Copyright 2025 European Parliament.
#
# Licensed under the European Union Public License (EUPL), Version 1.2 or subsequent
# versions of the EUPL (the "Licence"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
# https://eupl.eu/1.2/en/
#
# or in the "license" file accomying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.
import os
import logging
from typing import Optional, Dict
import boto3
from botocore.exceptions import BotoCoreError, ClientError
import random

# Set up basic logging configuration
logger = logging.getLogger(__name__)

# Default content types mapping
CONTENT_TYPE_MAP = {
    "csv:": "text/csv",
    "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "htm": "text/html",
    "html": "text/html",
    "jpeg": "image/jpeg",
    "jpg": "image/jpeg",
    "md": "text/markdown",
    "msg": "application/vnd.ms-outlook",
    "pdf": "application/pdf",
    "pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    "txt": "text/plain",
    "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
}

# Default expiration time for presigned URLs in seconds
DEFAULT_EXPIRES_IN = int(os.getenv("PRESIGNED_URL_EXPIRES_IN", "1200"))


def infer_content_type(file_name: str) -> str:
    """
    Infer the content type from the file extension.
    Falls back to 'application/octet-stream' if unknown.
    """
    extension = os.path.splitext(file_name)[1].lower().lstrip(".")
    return CONTENT_TYPE_MAP.get(extension, "application/octet-stream")

def generate_presigned_url(client_method: str, params: Dict) -> Optional[str]:
    """
    Generate a pre-signed URL using a specific S3 client method.

    Args:
        client_method (str): The boto3 S3 client method (e.g., 'put_object').
        params (Dict): Parameters required by the client method.

    Returns:
        Optional[str]: Pre-signed URL if successful, otherwise None.
    """
    region = os.getenv("AWS_REGION", "eu-central-1")

    try:
        s3_client = boto3.client('s3', region_name=region)
        url = s3_client.generate_presigned_url(
            ClientMethod=client_method,
            Params=params,
            ExpiresIn=DEFAULT_EXPIRES_IN
        )
        return url
    except (ClientError, BotoCoreError) as e:
        logger.error("Failed to generate pre-signed URL with method '%s': %s", client_method, e)
        return None

def generate_presigned_put_url(bucket_name: str, file_name: Optional[str] = None, content_type: Optional[str] = None) -> Optional[str]:
    """
    Generate a pre-signed PUT URL to upload a file to S3.

    Args:
        bucket_name (str): The name of the S3 bucket.
        file_name (Optional[str]): The name of the file to upload. A random name is used if not provided.
        content_type (Optional[str]): The MIME type of the file.

    Returns:
        Optional[str]: The pre-signed URL or None if generation fails.
    """
    obj_key = file_name or str(random.randint(1, 100000))
    content_type = content_type or (infer_content_type(file_name) if file_name else "application/octet-stream")

    return generate_presigned_url("put_object", {
        'Bucket': bucket_name,
        'Key': obj_key,
        'ContentType': content_type
    })

def generate_presigned_get_url(bucket_name: str, file_name: str) -> Optional[str]:
    """
    Generate a pre-signed GET URL to download a file from S3.

    Args:
        bucket_name (str): The name of the S3 bucket.
        file_name (str): The name of the file to download.

    Returns:
        Optional[str]: The pre-signed URL or None if generation fails.
    """
    return generate_presigned_url("get_object", {
        'Bucket': bucket_name,
        'Key': file_name
    })

def generate_presigned_list_bucket_url(bucket_name: str, prefix: str=None) -> Optional[str]:
    """
    Generate a pre-signed URL to list objects in an S3 bucket.

    Args:
        bucket_name (str): The name of the S3 bucket.

    Returns:
        Optional[str]: The pre-signed URL or None if generation fails.
    """
    params = {'Bucket': bucket_name}

    if prefix is not None:
        params["Prefix"] = prefix

    return generate_presigned_url("list_objects", params)

def generate_presigned_delete_url(bucket_name: str, file_name: str) -> Optional[str]:
    """
    Generate a pre-signed DELETE URL to delete a file in S3.

    Args:
        bucket_name (str): The name of the S3 bucket.
        file_name (str): The name of the file to delete.

    Returns:
        Optional[str]: The pre-signed URL or None if generation fails.
    """
    return generate_presigned_url("delete_object", {
        'Bucket': bucket_name,
        'Key': file_name
    })

# def upload_lambda_payload(payload: Dict,
#                           bucket_name: str = None,
#                           s3_payload_key: str = None) -> Optional[Dict]:
#     """
#     It saves the payload received in input on the 'bucket_name' s3
#     :param payload: the payload to be temporarily saved
#     :type payload: Dict
#     :param bucket_name: name of the s3 bucket where the payload will be saved
#     :type bucket_name: str
#     :param s3_payload_key: name of the temporary payload file. If None, it will be generated now()+random int
#     :type s3_payload_key: str
#     :return: object key of the json file containing the payload
#     :rtype: Dict
#     """
#
#     OBJ_KEY_PREFIX = "tmp/"
#
#     if s3_payload_key is None:
#         s3_payload_key = f"{datetime.now().timestamp()}-{random.randint(1000000, 9999999)}.json"
#
#     config = config_manager.get_configuration()
#     region = config.get("aws", {}).get("region", os.getenv("AWS_REGION", "eu-central-1"))
#
#     # Save the payload on the specified bucket.
#     # -----------------------------------------
#     object_key = f"{OBJ_KEY_PREFIX}{s3_payload_key}"
#     json_data = json.dumps(payload)
#
#     try:
#         s3_client = boto3.client('s3', region_name=region)
#         s3_client.put_object(
#             Bucket=bucket_name,
#             Key=object_key,
#             Body=json_data,
#             ContentType='application/json'
#         )
#         logger.info(f"Payload successfully stored in bucket {bucket_name} with key {object_key}")
#         return {"bucket": bucket_name, "obj_key": object_key}
#     except (ClientError, BotoCoreError) as e:
#         logger.error("Failed to generate pre-signed URL to save %s on %s: %s", object_key, bucket_name, e)
#         return None


def main():
    """
    Example usage and test of the presigned URL generation.
    Requires AWS credentials and appropriate permissions.
    """
    bucket = os.getenv("ep-archives-tools-docs", "ep-archives-tools-docs")
    file_name = "Pippo.pdf"

    url = generate_presigned_put_url(bucket_name=bucket, file_name=file_name, )
    if url:
        print(f"Generated PUT URL:\n{url}")
    else:
        print("Failed to generate PUT URL.")

if __name__ == "__main__":
    main()
