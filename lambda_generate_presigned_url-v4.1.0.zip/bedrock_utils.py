# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
#
# Permission is hereby granted, free of charge, to any person obtaining a copy of this
# software and associated documentation files (the "Software"), to deal in the Software
# without restriction, including without limitation the rights to use, copy, modify,
# merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
# PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""Utils related to accessing Bedrock"""

import json
import logging
import os
from abc import ABC, abstractmethod

from botocore.client import BaseClient
from botocore.exceptions import ClientError
from pydantic import BaseModel, Field, PrivateAttr
from typing import Optional, Dict, Any

import boto3
from botocore.config import Config

logger = logging.getLogger(__name__)

def _get_bedrock_client(
    assumed_role: Optional[str] = None,
    region: Optional[str] = None,
    runtime: Optional[bool] = True,
    agent: Optional[bool] = False,
):
    """Create a boto3 client for Amazon Bedrock or for Amazon Bedrock Agents,
    with optional configuration overrides

    Parameters
    ----------
    assumed_role :
        Optional ARN of an AWS IAM role to assume for calling the Bedrock service. If not
        specified, the current active credentials will be used.
    region :
        Optional name of the AWS Region in which the service should be called (e.g. "us-east-1").
        If not specified, AWS_REGION or AWS_DEFAULT_REGION environment variable will be used.
    runtime :
        Optional choice of getting different client to perform operations with the Amazon Bedrock service.
    agent :
        Return a bedrock-agent-runtime client instead of bedrock or bedrock-runtime
    """
    if region is None:
        target_region = os.environ.get(
            "AWS_REGION", os.environ.get("AWS_DEFAULT_REGION")
        )
    else:
        target_region = region

    logger.info(f"Create new client\n  Using region: {target_region}")
    session_kwargs = {"region_name": target_region}
    client_kwargs = {**session_kwargs}

    profile_name = os.environ.get("AWS_PROFILE")
    if profile_name:
        logger.info(f"  Using profile: {profile_name}")
        session_kwargs["profile_name"] = profile_name

    retry_config = Config(
        region_name=target_region,
        retries={
            "max_attempts": 1,
            "mode": "standard",
        },
        read_timeout=300,  # 5 min read timeout
    )
    session = boto3.Session(**session_kwargs)

    if assumed_role:
        logger.info(f"  Using role: {assumed_role}", end="")
        sts = session.client("sts")
        response = sts.assume_role(
            RoleArn=str(assumed_role), RoleSessionName="langchain-llm-1"
        )
        logger.info(" ... successful!")
        client_kwargs["aws_access_key_id"] = response["Credentials"]["AccessKeyId"]
        client_kwargs["aws_secret_access_key"] = response["Credentials"][
            "SecretAccessKey"
        ]
        client_kwargs["aws_session_token"] = response["Credentials"]["SessionToken"]

    if agent:
        service_name = "bedrock-agent-runtime"
    elif runtime:
        service_name = "bedrock-runtime"
    else:
        service_name = "bedrock"

    bedrock_client = session.client(
        service_name=service_name, config=retry_config, **client_kwargs
    )

    logger.info("boto3 Bedrock client successfully created!")
    logger.info(f"{bedrock_client._endpoint=}")
    return bedrock_client

class AbstractLlm(BaseModel, ABC):
    """Class to invoke Bedrock foundation models for generation (messages API)"""

    model_id: str = Field(..., description="Bedrock model ID")
    body: Dict[str, Any] = Field(..., description="Request body")
    stream: bool = Field(False, description="Streamed answer")

    @abstractmethod
    def generate(self) -> Dict[str, Any]:
        pass

    @abstractmethod
    def close(self):
        pass

class BedrockLlm(AbstractLlm):

    _bedrock_client: BaseClient = PrivateAttr()

    def model_post_init(self, __context):
        """Loads configuration after validation."""
        self._bedrock_client = _get_bedrock_client(
            assumed_role=os.environ.get("BEDROCK_ASSUME_ROLE", None),
            region=os.environ.get("AWS_DEFAULT_REGION", "eu-central-1"),
        )

    def _invoke(self) -> Dict[str, Any]:
        if self.stream:
            response = self._bedrock_client.invoke_model_with_response_stream(
                modelId=self.model_id,
                body=json.dumps(self.body),
                contentType="application/json"
            )
            return response
        else:
            response = self._bedrock_client.invoke_model(
                modelId=self.model_id, body=json.dumps(self.body)
            )

            return response

    def generate(self) -> Optional[Dict[str, Any]]:
        """
        Generate a response from a Bedrock model using the Messages API.

        Args:

        Returns:
            Dict[str, Any]: The parsed response body from the model.
        """

        logger.debug("BEGIN Body\n" + "=" * 20)
        logger.debug({json.dumps(self.body, indent=2)})
        logger.debug("END Body\n" + "=" * 20)

        # Call Bedrock API
        try:
            response = self._invoke()
            return response

        except (ClientError, Exception) as e:
            logger.error(f"ERROR: Can't invoke '{self.model_id}'. Reason: {e}")
            return None

    def close(self):
        self._bedrock_client.close()


    # def __init__(self):
    #     self.accept = "application/json"
    #     self.content_type = "application/json"
    #     self.boto3_bedrock =

    # def generate(
    #     self,
    #     model_id: str,
    #     system_prompt: str,
    #     content: Union[str, List[Dict[str, Any]]],
    #     stream: Optional[bool] = None,
    #     kwargs: Dict[str, Any] | None = None,
    # ) -> Dict[str, Any]:

        # # Decode the response body safely
        # response_body = json.loads(response["body"].read().decode("utf-8"))
        #
        # # Log token usage if available
        # usage = response_body.get("usage", {})
        # logger.info(
        #     "Token usage | input={0}, cache_created={1}, cache_read={2}, output={3}".format(
        #     usage.get("input_tokens"),
        #     usage.get("cache_creation_input_tokens"),
        #     usage.get("cache_read_input_tokens"),
        #     usage.get("output_tokens"),
        #     )
        # )
